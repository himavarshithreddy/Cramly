import SwiftUI
import CoreData
import AVFoundation
import Speech
import PhotosUI
import Vision
import UIKit

// MARK: - Core Data Model Setup (unchanged)
func createManagedObjectModel() -> NSManagedObjectModel {
    let model = NSManagedObjectModel()
    
    let subjectEntity = NSEntityDescription()
    subjectEntity.name = "Subject"
    subjectEntity.managedObjectClassName = NSStringFromClass(Subject.self)
    
    let subjectNameAttribute = NSAttributeDescription()
    subjectNameAttribute.name = "name"
    subjectNameAttribute.attributeType = .stringAttributeType
    subjectNameAttribute.isOptional = false
    
    let revisionRelationship = NSRelationshipDescription()
    revisionRelationship.name = "revisionPoints"
    revisionRelationship.minCount = 0
    revisionRelationship.maxCount = 0
    revisionRelationship.deleteRule = .cascadeDeleteRule
    
    subjectEntity.properties = [subjectNameAttribute, revisionRelationship]
    
    let revisionEntity = NSEntityDescription()
    revisionEntity.name = "RevisionPoint"
    revisionEntity.managedObjectClassName = NSStringFromClass(RevisionPoint.self)
    
    let revisionTextAttribute = NSAttributeDescription()
    revisionTextAttribute.name = "text"
    revisionTextAttribute.attributeType = .stringAttributeType
    revisionTextAttribute.isOptional = true
    
    let revisionImageDataAttribute = NSAttributeDescription()
    revisionImageDataAttribute.name = "imageData"
    revisionImageDataAttribute.attributeType = .binaryDataAttributeType
    revisionImageDataAttribute.isOptional = true
    
    let revisionAudioDataAttribute = NSAttributeDescription()
    revisionAudioDataAttribute.name = "audioData"
    revisionAudioDataAttribute.attributeType = .binaryDataAttributeType
    revisionAudioDataAttribute.isOptional = true
    
    let subjectRelationship = NSRelationshipDescription()
    subjectRelationship.name = "subject"
    subjectRelationship.destinationEntity = subjectEntity
    subjectRelationship.minCount = 1
    subjectRelationship.maxCount = 1
    subjectRelationship.deleteRule = .nullifyDeleteRule
    
    revisionEntity.properties = [revisionTextAttribute, revisionImageDataAttribute, revisionAudioDataAttribute, subjectRelationship]
    
    revisionRelationship.destinationEntity = revisionEntity
    revisionRelationship.inverseRelationship = subjectRelationship
    subjectRelationship.inverseRelationship = revisionRelationship
    
    model.entities = [subjectEntity, revisionEntity]
    return model
}

// MARK: - NSManagedObject Subclasses (unchanged)
class Subject: NSManagedObject, Identifiable {
    @NSManaged var name: String
    @NSManaged var revisionPoints: Set<RevisionPoint>
}

class RevisionPoint: NSManagedObject, Identifiable {
    @NSManaged var text: String?
    @NSManaged var imageData: Data?
    @NSManaged var audioData: Data?
    @NSManaged var subject: Subject
}

// MARK: - Persistence Controller (unchanged)
struct PersistenceController {
    static let shared = PersistenceController()

    let container: NSPersistentContainer

    init(inMemory: Bool = false) {
        let model = createManagedObjectModel()
        container = NSPersistentContainer(name: "RevisionModel", managedObjectModel: model)
        if inMemory {
            container.persistentStoreDescriptions.first?.url = URL(fileURLWithPath: "/dev/null")
        }
        container.loadPersistentStores { storeDescription, error in
            if let error = error as NSError? {
                fatalError("Unresolved error \(error), \(error.userInfo)")
            }
        }
    }
}

// MARK: - Color Scheme
extension Color {
    static let primaryAccent = Color.blue
    static let cardBackground = Color(red: 27/255, green: 27/255, blue: 27/255) // Smooth gray
    static let appBackground = Color.black
}

// MARK: - Main App Entry Point
@main
struct CramlyApp: App {
    let persistenceController = PersistenceController.shared

    var body: some Scene {
        WindowGroup {
            ContentView()
                .environment(\.managedObjectContext, persistenceController.container.viewContext)
                .preferredColorScheme(.dark)
                .accentColor(.primaryAccent)
        }
    }
}

// MARK: - SwiftUI Views

// Home Screen: List of Subjects
struct ContentView: View {
    @Environment(\.managedObjectContext) private var viewContext
    
    @FetchRequest(
        sortDescriptors: [NSSortDescriptor(keyPath: \Subject.name, ascending: true)],
        animation: .default)
    private var subjects: FetchedResults<Subject>
    
    @State private var showAddSubject = false
    
    var body: some View {
        NavigationView {
            ZStack {
                Color.appBackground
                    .ignoresSafeArea()
                
                if subjects.isEmpty {
                    VStack(spacing: 20) {
                        Text("No Subjects Yet")
                            .font(.title2)
                            .foregroundColor(.white)
                        
                        Text("Tap the + button to add your first subject!\nStart organizing your revision notes.")
                            .font(.body)
                            .multilineTextAlignment(.center)
                            .foregroundColor(.gray)
                            .padding(.horizontal)
                    }
                    .frame(maxWidth: .infinity, maxHeight: .infinity)
                } else {
                    List {
                        ForEach(subjects) { subject in
                            NavigationLink(destination: SubjectDetailView(subject: subject)) {
                                HStack {
                                    Image(systemName: "book.fill")
                                        .foregroundColor(.primaryAccent)
                                    Text(subject.name)
                                        .font(.headline)
                                        .foregroundColor(.white)
                                }
                                .frame(height: 40)
                                .padding(.vertical, 4)
                            }
                        }
                        .onDelete(perform: deleteSubjects)
                        .listRowBackground(Color.cardBackground)
                    }
                    .listStyle(PlainListStyle())
                }
            }
            .navigationTitle("My Subjects")
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button(action: { showAddSubject = true }) {
                        Image(systemName: "plus.circle.fill")
                            .font(.title2)
                    }
                }
                ToolbarItem(placement: .navigationBarLeading) {
                    EditButton()
                }
            }
            .sheet(isPresented: $showAddSubject) {
                AddSubjectView(showAddSubject: $showAddSubject)
                    .environment(\.managedObjectContext, viewContext)
            }
        }
    }
    
    private func deleteSubjects(offsets: IndexSet) {
        withAnimation(.easeInOut) {
            offsets.map { subjects[$0] }.forEach(viewContext.delete)
            saveContext()
        }
    }
    
    private func saveContext() {
        do {
            try viewContext.save()
        } catch {
            print("Error saving context: \(error)")
        }
    }
}

// Add New Subject View
struct AddSubjectView: View {
    @Environment(\.managedObjectContext) private var viewContext
    @Binding var showAddSubject: Bool
    @State private var subjectName = ""
    
    var body: some View {
        NavigationView {
            ZStack {
                Color.appBackground
                    .ignoresSafeArea()
                
                VStack(spacing: 20) {
                    TextField("Subject Name", text: $subjectName)
                        .padding()
                        .background(Color.cardBackground)
                        .cornerRadius(10)
                        .overlay(
                            RoundedRectangle(cornerRadius: 10)
                                .stroke(Color.primaryAccent.opacity(0.3), lineWidth: 1)
                        )
                        .shadow(radius: 2)
                        .font(.headline)
                        .foregroundColor(.white)
                    
                    Button("Save") {
                        if !subjectName.trimmingCharacters(in: .whitespaces).isEmpty {
                            addSubject()
                        }
                    }
                    .font(.headline)
                    .frame(maxWidth: .infinity)
                    .padding()
                    .background(subjectName.trimmingCharacters(in: .whitespaces).isEmpty ? Color.gray : Color.primaryAccent)
                    .foregroundColor(.white)
                    .cornerRadius(12)
                    .disabled(subjectName.trimmingCharacters(in: .whitespaces).isEmpty)
                    
                    Spacer()
                }
                .padding()
            }
            .navigationTitle("New Subject")
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("Cancel") {
                        showAddSubject = false
                    }
                    .foregroundColor(.red)
                }
            }
        }
    }
    
    private func addSubject() {
        withAnimation {
            let newSubject = Subject(context: viewContext)
            newSubject.name = subjectName
            do {
                try viewContext.save()
                showAddSubject = false
            } catch {
                print("Error saving subject: \(error)")
            }
        }
    }
}

// Subject Detail View: Manage Revision Points & Inputs
struct SubjectDetailView: View {
    @ObservedObject var subject: Subject
    @Environment(\.managedObjectContext) private var viewContext
    
    @State private var newRevisionText = ""
    @State private var showPhotoInput = false
    @State private var showCameraInput = false
    @State private var showAudioInput = false
    
    var body: some View {
        ZStack {
            Color.appBackground
                .ignoresSafeArea()
            
            VStack(spacing: 5) {
                if subject.revisionPoints.isEmpty {
                    VStack(spacing: 20) {
                        Text("No Revision Points Yet")
                            .font(.title2)
                            .foregroundColor(.white)
                        
                        Text("Add your first revision point below!\nSupports text notes, images, and audio recordings.")
                            .font(.body)
                            .multilineTextAlignment(.center)
                            .foregroundColor(.gray)
                            .padding(.horizontal)
                    }
                    .frame(maxWidth: .infinity, maxHeight: .infinity)
                } else {
                    List {
                        ForEach(Array(subject.revisionPoints), id: \.self) { revision in
                            VStack(alignment: .leading, spacing: 8) {
                                if let imageData = revision.imageData, let uiImage = UIImage(data: imageData) {
                                    Image(uiImage: uiImage)
                                        .resizable()
                                        .scaledToFit()
                                        .frame(maxHeight: 200)
                                        .cornerRadius(8)
                                } else if let audioData = revision.audioData {
                                    HStack {
                                        Image(systemName: "waveform")
                                        Text("Audio Recording")
                                            .font(.subheadline)
                                    }
                                    .foregroundColor(.accentColor)
                                } else {
                                    Text(revision.text ?? "No text")
                                        .font(.body)
                                        .foregroundColor(.white)
                                }
                            }
                            .padding()
                            .frame(maxWidth: .infinity)
                            .background(Color.cardBackground)
                            .cornerRadius(12)
                            .shadow(radius: 2)
                        }
                        .onDelete(perform: deleteRevisionPoints)
                        .listRowBackground(Color.clear)
                        .listRowSeparator(.hidden)
                    }
                    .listStyle(PlainListStyle())
                }
                
                VStack(spacing: 20) {
                    HStack {
                        TextField("Add revision point", text: $newRevisionText)
                            .padding()
                            .background(Color.cardBackground)
                            .cornerRadius(10)
                            .overlay(
                                RoundedRectangle(cornerRadius: 10)
                                    .stroke(Color.primaryAccent.opacity(0.8), lineWidth: 1)
                            )
                            .submitLabel(.done)
                            .onSubmit {
                                if !newRevisionText.trimmingCharacters(in: .whitespaces).isEmpty {
                                    addRevisionPoint(text: newRevisionText, imageData: nil, audioData: nil)
                                    newRevisionText = ""
                                }
                            }
                            .foregroundColor(.white)
                        
                        Button(action: {
                            if !newRevisionText.trimmingCharacters(in: .whitespaces).isEmpty {
                                addRevisionPoint(text: newRevisionText, imageData: nil, audioData: nil)
                                newRevisionText = ""
                            }
                        }) {
                            Image(systemName: "plus.circle.fill")
                                .font(.title2)
                        }
                        .disabled(newRevisionText.trimmingCharacters(in: .whitespaces).isEmpty)
                    }
                    
                    HStack(spacing: 10) {
                        InputButton(icon: "photo", title: "Photo", color: .primaryAccent) { showPhotoInput = true }
                        InputButton(icon: "camera", title: "Camera", color: .primaryAccent) { showCameraInput = true }
                        InputButton(icon: "mic", title: "Audio", color: .primaryAccent) { showAudioInput = true }
                    }
                    
                    if !subject.revisionPoints.isEmpty {
                        NavigationLink(destination: RevisionSessionView(revisionPoints: Array(subject.revisionPoints))) {
                            Text("Start Revision")
                                .font(.headline)
                                .frame(maxWidth: .infinity)
                                .padding()
                                .background(Color.primaryAccent)
                                .foregroundColor(.white)
                                .cornerRadius(12)
                                .shadow(radius: 2)
                        }
                    }
                }
                .padding()
                .frame(maxWidth: .infinity)
                .background(Color.cardBackground)
                .cornerRadius(12)
                .shadow(radius: 2)
                .padding(.horizontal)
            }
        }
        .navigationTitle(subject.name)
        .sheet(isPresented: $showPhotoInput) {
            PhotoInputView { text, imageData in
                addRevisionPoint(text: text, imageData: imageData, audioData: nil)
            }
        }
        .sheet(isPresented: $showCameraInput) {
            CameraInputView { text, imageData in
                addRevisionPoint(text: text, imageData: imageData, audioData: nil)
            }
        }
        .sheet(isPresented: $showAudioInput) {
            AudioInputView { text, audioData in
                addRevisionPoint(text: text, imageData: nil, audioData: audioData)
            }
        }
    }
    
    private func addRevisionPoint(text: String?, imageData: Data?, audioData: Data?) {
        guard text != nil || imageData != nil || audioData != nil else { return }
        withAnimation(.easeInOut) {
            let revision = RevisionPoint(context: viewContext)
            revision.text = text
            revision.imageData = imageData
            revision.audioData = audioData
            revision.subject = subject
            do {
                try viewContext.save()
            } catch {
                print("Error saving revision point: \(error)")
            }
        }
    }
    
    private func deleteRevisionPoints(offsets: IndexSet) {
        withAnimation(.easeInOut) {
            let revisionsArray = Array(subject.revisionPoints)
            offsets.map { revisionsArray[$0] }.forEach(viewContext.delete)
            do {
                try viewContext.save()
            } catch {
                print("Error deleting revision point: \(error)")
            }
        }
    }
}

// Custom Input Button Component
struct InputButton: View {
    let icon: String
    let title: String
    let color: Color
    let action: () -> Void
    
    var body: some View {
        Button(action: action) {
            VStack(spacing: 5) {
                Image(systemName: icon)
                    .font(.title2)
                Text(title)
                    .font(.caption)
            }
            .frame(maxWidth: .infinity)
            .padding()
            .background(color.opacity(0.1))
            .cornerRadius(10)
        }
        .foregroundColor(color)
    }
}

// Revision Session View: Flashcard-like Revision
struct RevisionSessionView: View {
    let revisionPoints: [RevisionPoint]
    @State private var currentIndex = 0
    @State private var audioPlayer: AVAudioPlayer?
    @State private var isPlaying = false
    @GestureState private var dragOffset = CGSize.zero
    
    var body: some View {
        GeometryReader { geometry in
            ZStack {
                RadialGradient(
                    gradient: Gradient(colors: [Color.primaryAccent.opacity(0.1), .appBackground]),
                    center: .center,
                    startRadius: 150,
                    endRadius: 800
                )
                .ignoresSafeArea()
                
                VStack(spacing: 20) {
                    Spacer()
                    
                    if revisionPoints.isEmpty {
                        Text("No revision points available")
                            .font(.title2)
                            .padding()
                            .frame(minWidth: geometry.size.width * 0.85, minHeight: 300)
                            .background(Color.clear)
                            .cornerRadius(15)
                            .shadow(color: .primaryAccent.opacity(0.6), radius: 10)
                            .foregroundColor(.white)
                    } else {
                        ZStack {
                            ForEach(0..<revisionPoints.count, id: \.self) { index in
                                if index == currentIndex {
                                    CardView(
                                        revisionPoint: revisionPoints[index],
                                        isPlaying: $isPlaying,
                                        playAudio: { playAudio(data: revisionPoints[index].audioData) },
                                        geometry: geometry
                                    )
                                    .frame(width: geometry.size.width * 0.85)
                                    .offset(x: dragOffset.width)
                                    .rotationEffect(.degrees(Double(dragOffset.width / 20)))
                                    .transition(.asymmetric(insertion: .scale, removal: .opacity))
                                }
                            }
                        }
                    }
                    
                    Spacer()
                    
                    HStack(spacing: 20) {
                        NavigationButton(
                            title: "Previous",
                            isEnabled: currentIndex > 0,
                            action: {
                                stopAudio()
                                withAnimation(.spring()) { currentIndex -= 1 }
                            }
                        )
                        Spacer()
                        NavigationButton(
                            title: "Next",
                            isEnabled: currentIndex < revisionPoints.count - 1,
                            action: {
                                stopAudio()
                                withAnimation(.spring()) { currentIndex += 1 }
                            }
                        )
                    }
                    .padding(.horizontal, 30)
                    .padding(.bottom, 20)
                }
                .frame(maxWidth: .infinity, maxHeight: .infinity)
                .background(
                    RadialGradient(
                        gradient: Gradient(colors: [
                            Color.blue.opacity(0.1),
                            Color.black
                        ]),
                        center: .center,
                        startRadius: 100,
                        endRadius: 600
                    )
                    .ignoresSafeArea()
                )
            }
            .navigationTitle("Revision Session")
            .gesture(
                DragGesture()
                    .updating($dragOffset) { value, state, _ in
                        state = value.translation
                    }
                    .onEnded { value in
                        let threshold: CGFloat = 100
                        if value.translation.width < -threshold, currentIndex < revisionPoints.count - 1 {
                            stopAudio()
                            withAnimation(.spring()) { currentIndex += 1 }
                        } else if value.translation.width > threshold, currentIndex > 0 {
                            stopAudio()
                            withAnimation(.spring()) { currentIndex -= 1 }
                        }
                    }
            )
            .onDisappear {
                stopAudio()
            }
        }
    }
    
    private func playAudio(data: Data?) {
        guard let audioData = data else { return }
        do {
            // Configure audio session for playback
            let audioSession = AVAudioSession.sharedInstance()
            try audioSession.setCategory(.playback, mode: .default)
            try audioSession.setActive(true)
            
            audioPlayer = try AVAudioPlayer(data: audioData)
            audioPlayer?.prepareToPlay()
            audioPlayer?.play()
            isPlaying = true
            audioPlayer?.delegate = AudioPlayerDelegate { isPlaying = false }
        } catch {
            print("Error playing audio: \(error)")
        }
    }
    
    private func stopAudio() {
        audioPlayer?.stop()
        isPlaying = false
        do {
            try AVAudioSession.sharedInstance().setActive(false)
        } catch {
            print("Error deactivating audio session: \(error)")
        }
    }
}

// Audio Player Delegate
class AudioPlayerDelegate: NSObject, AVAudioPlayerDelegate {
    let onFinish: () -> Void
    
    init(onFinish: @escaping () -> Void) {
        self.onFinish = onFinish
    }
    
    func audioPlayerDidFinishPlaying(_ player: AVAudioPlayer, successfully flag: Bool) {
        onFinish()
    }
}

// Card View for Flashcards
// Card View for Flashcards
struct CardView: View {
    let revisionPoint: RevisionPoint
    @Binding var isPlaying: Bool
    let playAudio: () -> Void
    let geometry: GeometryProxy
    @State private var isExpanded = false
    
    var body: some View {
        VStack {
            if let imageData = revisionPoint.imageData, let uiImage = UIImage(data: imageData) {
                Image(uiImage: uiImage)
                    .resizable()
                    .scaledToFit()
                    .frame(maxHeight: isExpanded ? geometry.size.height * 0.8 : 200)
                    .cornerRadius(8)
            } else if let audioData = revisionPoint.audioData {
                VStack(spacing: 15) {
                    Image(systemName: isPlaying ? "stop.circle.fill" : "play.circle.fill")
                        .font(.system(size: 50))
                        .onTapGesture {
                            playAudio()
                        }
                    Text("Audio Recording")
                        .font(.title3)
                }
                .foregroundColor(.accentColor)
                .frame(maxHeight: isExpanded ? geometry.size.height * 0.8 : 300)
            } else {
                ScrollView(.vertical, showsIndicators: true) {
                    Text(revisionPoint.text ?? "No text")
                        .font(.title3)
                        .multilineTextAlignment(.center)
                        .foregroundColor(.white)
                        .padding()
                        .frame(maxWidth: .infinity, minHeight: isExpanded ? geometry.size.height * 0.8 : 300) // Ensures centering for small texts
                }
                .frame(maxHeight: isExpanded ? geometry.size.height * 0.8 : 300)
            }
        }
        .frame(maxWidth: .infinity)
        .background(Color.black)
        .cornerRadius(15)
        .shadow(color: .primaryAccent.opacity(0.6), radius: 10)
        .gesture(
            LongPressGesture(minimumDuration: 0.5)
                .onEnded { _ in
                    withAnimation(.easeInOut) {
                        isExpanded.toggle()
                    }
                }
        )
    }
}
// Navigation Button Component
struct NavigationButton: View {
    let title: String
    let isEnabled: Bool
    let action: () -> Void
    
    var body: some View {
        Button(action: action) {
            Text(title)
                .font(.headline)
                .padding()
                .frame(maxWidth: .infinity)
                .background(isEnabled ? Color.primaryAccent : Color.gray)
                .foregroundColor(.white)
                .cornerRadius(12)
        }
        .disabled(!isEnabled)
    }
}

// MARK: - Photo Input View
struct PhotoInputView: View {
    @Environment(\.dismiss) var dismiss
    var onSave: (String?, Data?) -> Void
    
    @State private var selectedItem: PhotosPickerItem? = nil
    @State private var imageData: Data?
    @State private var editableText: String = ""
    @State private var saveOption: SaveOption = .none
    
    enum SaveOption {
        case none, text, image
    }
    
    var body: some View {
        ZStack {
            Color.appBackground
                .ignoresSafeArea()
            
            VStack(spacing: 20) {
                PhotosPicker(selection: $selectedItem, matching: .images, photoLibrary: .shared()) {
                    Label("Pick a Photo", systemImage: "photo")
                        .font(.headline)
                        .padding()
                        .frame(maxWidth: .infinity)
                        .background(Color.primaryAccent.opacity(0.1))
                        .foregroundColor(.primaryAccent)
                        .cornerRadius(12)
                }
                .onChange(of: selectedItem) { newItem in
                    Task {
                        if let data = try? await newItem?.loadTransferable(type: Data.self) {
                            imageData = data
                            if let uiImage = UIImage(data: data) {
                                let text = extractText(from: uiImage)
                                editableText = text
                            }
                        }
                    }
                }
                
                if let data = imageData, let uiImage = UIImage(data: data) {
                    Image(uiImage: uiImage)
                        .resizable()
                        .scaledToFit()
                        .frame(maxHeight: 200)
                        .cornerRadius(8)
                        .shadow(radius: 2)
                    
                    if !editableText.isEmpty {
                        TextEditor(text: $editableText)
                            .frame(height: 150)
                            .padding(8)
                            .background(Color.cardBackground)
                            .cornerRadius(12)
                            .shadow(radius: 2)
                            .foregroundColor(.white)
                    }
                    
                    Picker("Save Option", selection: $saveOption) {
                        Text("Select Option").tag(SaveOption.none)
                        Text("Save as Text").tag(SaveOption.text)
                        Text("Save as Image").tag(SaveOption.image)
                    }
                    .pickerStyle(SegmentedPickerStyle())
                    
                    Button("Save") {
                        switch saveOption {
                        case .text: onSave(editableText, nil)
                        case .image: onSave(nil, imageData)
                        case .none: return
                        }
                        dismiss()
                    }
                    .font(.headline)
                    .frame(maxWidth: .infinity)
                    .padding()
                    .background(saveOption == .none ? Color.gray : Color.primaryAccent)
                    .foregroundColor(.white)
                    .cornerRadius(12)
                    .disabled(saveOption == .none)
                }
                
                Spacer()
            }
            .padding()
        }
        .navigationTitle("Photo Input")
    }
    
    func extractText(from image: UIImage) -> String {
        guard let cgImage = image.cgImage else { return "" }
        let requestHandler = VNImageRequestHandler(cgImage: cgImage, options: [:])
        let request = VNRecognizeTextRequest { request, error in
            guard let observations = request.results as? [VNRecognizedTextObservation] else { return }
            let text = observations.compactMap { $0.topCandidates(1).first?.string }.joined(separator: "\n")
            DispatchQueue.main.async {
                self.editableText = text
            }
        }
        request.recognitionLevel = .accurate
        do {
            try requestHandler.perform([request])
            guard let observations = request.results else { return "" }
            return observations.compactMap { $0.topCandidates(1).first?.string }.joined(separator: "\n")
        } catch {
            print("Error performing text recognition: \(error)")
            return ""
        }
    }
}

// MARK: - Camera Input View
struct CameraInputView: View {
    @Environment(\.dismiss) var dismiss
    @State private var isPresented = false
    @State private var capturedImage: UIImage?
    @State private var editableText: String = ""
    @State private var saveOption: SaveOption = .none
    var onSave: (String?, Data?) -> Void
    
    enum SaveOption {
        case none, text, image
    }
    
    var body: some View {
        ZStack {
            Color.appBackground
                .ignoresSafeArea()
            
            VStack(spacing: 20) {
                if let image = capturedImage {
                    Image(uiImage: image)
                        .resizable()
                        .scaledToFit()
                        .frame(maxHeight: 200)
                        .cornerRadius(8)
                        .shadow(radius: 2)
                    
                    if !editableText.isEmpty {
                        TextEditor(text: $editableText)
                            .frame(height: 150)
                            .padding(8)
                            .background(Color.cardBackground)
                            .cornerRadius(12)
                            .shadow(radius: 2)
                            .foregroundColor(.white)
                    }
                    
                    Picker("Save Option", selection: $saveOption) {
                        Text("Select Option").tag(SaveOption.none)
                        Text("Save as Text").tag(SaveOption.text)
                        Text("Save as Image").tag(SaveOption.image)
                    }
                    .pickerStyle(SegmentedPickerStyle())
                }
                
                Button("Take Photo") {
                    isPresented = true
                }
                .font(.headline)
                .frame(maxWidth: .infinity)
                .padding()
                .background(Color.primaryAccent.opacity(0.1))
                .foregroundColor(.primaryAccent)
                .cornerRadius(12)
                
                Button("Save") {
                    if let image = capturedImage {
                        switch saveOption {
                        case .text: onSave(editableText, nil)
                        case .image: onSave(nil, image.jpegData(compressionQuality: 0.8))
                        case .none: return
                        }
                        dismiss()
                    }
                }
                .font(.headline)
                .frame(maxWidth: .infinity)
                .padding()
                .background(saveOption == .none || capturedImage == nil ? Color.gray : Color.primaryAccent)
                .foregroundColor(.white)
                .cornerRadius(12)
                .disabled(saveOption == .none || capturedImage == nil)
                
                Spacer()
            }
            .padding()
        }
        .navigationTitle("Camera Input")
        .sheet(isPresented: $isPresented) {
            ImagePicker(sourceType: .camera) { image in
                capturedImage = image
                editableText = extractText(from: image)
            }
        }
    }
    
    func extractText(from image: UIImage) -> String {
        guard let cgImage = image.cgImage else { return "" }
        let requestHandler = VNImageRequestHandler(cgImage: cgImage, options: [:])
        let request = VNRecognizeTextRequest { request, error in
            guard let observations = request.results as? [VNRecognizedTextObservation] else { return }
            let text = observations.compactMap { $0.topCandidates(1).first?.string }.joined(separator: "\n")
            DispatchQueue.main.async {
                self.editableText = text
            }
        }
        request.recognitionLevel = .accurate
        do {
            try requestHandler.perform([request])
            guard let observations = request.results else { return "" }
            return observations.compactMap { $0.topCandidates(1).first?.string }.joined(separator: "\n")
        } catch {
            print("Error performing text recognition: \(error)")
            return ""
        }
    }
}

// MARK: - Audio Input View
struct AudioInputView: View {
    @Environment(\.dismiss) var dismiss
    var onSave: (String?, Data?) -> Void
    
    @State private var isRecording = false
    @State private var audioRecorder: AVAudioRecorder?
    @State private var audioURL: URL?
    @State private var editableText: String = ""
    @State private var saveOption: SaveOption = .none
    
    enum SaveOption {
        case none, text, audio
    }
    
    var body: some View {
        ZStack {
            Color.appBackground
                .ignoresSafeArea()
            
            VStack(spacing: 20) {
                if !editableText.isEmpty {
                    TextEditor(text: $editableText)
                        .frame(height: 150)
                        .padding(8)
                        .background(Color.cardBackground)
                        .cornerRadius(12)
                        .shadow(radius: 2)
                        .foregroundColor(.white)
                }
                
                Button(action: {
                    if isRecording {
                        stopRecording()
                    } else {
                        startRecording()
                    }
                }) {
                    Label(isRecording ? "Stop Recording" : "Start Recording", systemImage: isRecording ? "stop.circle" : "mic.circle")
                        .font(.headline)
                        .frame(maxWidth: .infinity)
                        .padding()
                        .background(isRecording ? Color.red.opacity(0.1) : Color.primaryAccent.opacity(0.1))
                        .foregroundColor(isRecording ? .red : .primaryAccent)
                        .cornerRadius(12)
                }
                
                if audioURL != nil {
                    Picker("Save Option", selection: $saveOption) {
                        Text("Select Option").tag(SaveOption.none)
                        Text("Save as Text").tag(SaveOption.text)
                        Text("Save as Audio").tag(SaveOption.audio)
                    }
                    .pickerStyle(SegmentedPickerStyle())
                }
                
                Button("Save") {
                    if audioURL != nil {
                        switch saveOption {
                        case .text: onSave(editableText, nil)
                        case .audio:
                            if let url = audioURL, let data = try? Data(contentsOf: url) {
                                onSave(nil, data)
                            }
                        case .none: return
                        }
                        dismiss()
                    }
                }
                .font(.headline)
                .frame(maxWidth: .infinity)
                .padding()
                .background(saveOption == .none || audioURL == nil ? Color.gray : Color.primaryAccent)
                .foregroundColor(.white)
                .cornerRadius(12)
                .disabled(saveOption == .none || audioURL == nil)
                
                Spacer()
            }
            .padding()
        }
        .navigationTitle("Audio Input")
        .onDisappear {
            stopRecording()
        }
    }
    
    func startRecording() {
        let audioSession = AVAudioSession.sharedInstance()
        do {
            try audioSession.setCategory(.record, mode: .default)
            try audioSession.setActive(true)
        } catch {
            print("Error setting up audio session: \(error)")
            return
        }
        
        let documentsPath = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
        let audioFilename = documentsPath.appendingPathComponent("recording-\(Date().timeIntervalSince1970).m4a")
        let settings: [String: Any] = [
            AVFormatIDKey: kAudioFormatMPEG4AAC,
            AVSampleRateKey: 44100,
            AVNumberOfChannelsKey: 1,
            AVEncoderAudioQualityKey: AVAudioQuality.high.rawValue
        ]
        
        do {
            audioRecorder = try AVAudioRecorder(url: audioFilename, settings: settings)
            audioRecorder?.record()
            isRecording = true
        } catch {
            print("Error starting recording: \(error)")
            isRecording = false
        }
    }
    
    func stopRecording() {
        audioRecorder?.stop()
        audioURL = audioRecorder?.url
        isRecording = false
        
        if let url = audioURL {
            transcribeAudio(from: url)
        }
        
        do {
            try AVAudioSession.sharedInstance().setActive(false)
        } catch {
            print("Error deactivating audio session: \(error)")
        }
    }
    
    func transcribeAudio(from url: URL) {
        guard let recognizer = SFSpeechRecognizer(locale: Locale.current), recognizer.isAvailable else {
            return
        }
        
        let request = SFSpeechURLRecognitionRequest(url: url)
        recognizer.recognitionTask(with: request) { result, error in
            if let result = result {
                DispatchQueue.main.async {
                    self.editableText = result.bestTranscription.formattedString
                }
            }
            if let error = error {
                print("Error transcribing audio: \(error)")
            }
        }
    }
}

// MARK: - ImagePicker Wrapper
struct ImagePicker: UIViewControllerRepresentable {
    let sourceType: UIImagePickerController.SourceType
    let onImagePicked: (UIImage) -> Void
    
    func makeUIViewController(context: Context) -> UIImagePickerController {
        let picker = UIImagePickerController()
        picker.sourceType = sourceType
        picker.delegate = context.coordinator
        return picker
    }
    
    func updateUIViewController(_ uiViewController: UIImagePickerController, context: Context) {}
    
    func makeCoordinator() -> Coordinator {
        Coordinator(onImagePicked: onImagePicked)
    }
    
    class Coordinator: NSObject, UIImagePickerControllerDelegate, UINavigationControllerDelegate {
        let onImagePicked: (UIImage) -> Void
        
        init(onImagePicked: @escaping (UIImage) -> Void) {
            self.onImagePicked = onImagePicked
        }
        
        func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
            if let image = info[.originalImage] as? UIImage {
                onImagePicked(image)
            }
            picker.dismiss(animated: true)
        }
        
        func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
            picker.dismiss(animated: true)
        }
    }
}
